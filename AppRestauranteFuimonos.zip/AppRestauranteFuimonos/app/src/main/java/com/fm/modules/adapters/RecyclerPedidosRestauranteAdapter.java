package com.fm.modules.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fm.apprestaurantefuimonos.R;
import com.fm.modules.app.login.Logon;
import com.fm.modules.app.login.Logued;
import com.fm.modules.app.pedidos.PlatillosSeleccionadoPorPedido;
import com.fm.modules.app.pedidos.Principal;
import com.fm.modules.entities.RespuestaPedidosDriver;
import com.fm.modules.models.Driver;
import com.fm.modules.models.Image;
import com.fm.modules.models.Menu;
import com.fm.modules.models.Pedido;
import com.fm.modules.models.PlatilloSeleccionado;
import com.fm.modules.models.RespuestaGenerica;
import com.fm.modules.models.Restaurante;
import com.fm.modules.models.Usuario;
import com.fm.modules.service.DriverService;
import com.fm.modules.service.PedidoService;
import com.fm.modules.service.PlatilloSeleccionadoService;
import com.fm.modules.service.RestauranteService;
import com.fm.modules.service.UsuarioService;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RecyclerPedidosRestauranteAdapter extends RecyclerView.Adapter<RecyclerPedidosRestauranteAdapter.ViewHolder> {

    List<RespuestaPedidosDriver> pedidosList;
    Context context;
    Locale espanol = new Locale("es","ES");
    SimpleDateFormat ffecha = new SimpleDateFormat("dd/MMM/yyyy", espanol);
    SimpleDateFormat fhora = new SimpleDateFormat("HH:mm:ss");
    DecimalFormat decimalFormat = new DecimalFormat("$ 0.00");
    FragmentActivity fragmentActivity;

    BuscarPedido buscarPedido = new BuscarPedido();

    public RecyclerPedidosRestauranteAdapter(Context context, List<RespuestaPedidosDriver> pedidosList, FragmentActivity fragmentActivity){
        this.context = context;
        this.pedidosList = pedidosList;
        this.fragmentActivity = fragmentActivity;
    }

    @NonNull
    @Override
    public RecyclerPedidosRestauranteAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.holder_item_ordenes_actuales, parent, false);
        return new RecyclerPedidosRestauranteAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerPedidosRestauranteAdapter.ViewHolder holder, int position) {
        //if(pedidosList.get(position).getStatus() == 0){
            holder.asignarDatos(pedidosList.get(position));
        //}else{

        //}



    }

    @Override
    public int getItemCount() {
        return pedidosList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        CheckBox checkBox;
        TextView tvNumeroOrdenH;
        TextView tvFechaH;
        TextView tvTotalH;
        Button leftArrow;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            checkBox = itemView.findViewById(R.id.checkbox);
            tvNumeroOrdenH = itemView.findViewById(R.id.tvNumeroOrdenH);
            tvFechaH = itemView.findViewById(R.id.tvFechaH);
            tvTotalH = itemView.findViewById(R.id.tvTotalH);
            leftArrow = itemView.findViewById(R.id.icon_leftArrow);
        }

        public void asignarDatos(final RespuestaPedidosDriver res){
            String precioPedido = decimalFormat.format(res.getTotalEnRestautante());
            if(res.getStatus() == 1){
                tvNumeroOrdenH.setText("Orden #" +res.getPedidoId() +" - Lista");
                tvFechaH.setText(ffecha.format(res.getFechaOrdenado()));
                tvTotalH.setText(precioPedido);
            }else{
                tvNumeroOrdenH.setText("Orden #" +res.getPedidoId());
                tvFechaH.setText(ffecha.format(res.getFechaOrdenado()));
                tvTotalH.setText(precioPedido);
            }

            leftArrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog(res);
                }
            });

        }

        public void dialog(final RespuestaPedidosDriver res){
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Pedido");
            builder.setMessage("¿Desea tomar este pedido?").setPositiveButton("Si", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(context, PlatillosSeleccionadoPorPedido.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("idPedido" , res.getPedidoId());
                    intent.putExtra("totalPedido" , decimalFormat.format(res.getTotalDePedido()));
                    intent.putExtra("status" , res.getStatus());
                    //showFragment(new PlatillosSeleccionadoPorPedido());
                    Logued.pedidoLogued = new Pedido();
                    Logued.pedidoLogued.setPedidoId(res.getPedidoId());
                    buscarPedido.execute();
                    context.startActivity(intent);
                }
            }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    //Toast.makeText(context, "No tomocesa este pedido..", Toast.LENGTH_SHORT).show();
                }
            }).show();
        }
    }

    private void showFragment(Fragment fragment) {
        fragmentActivity.getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, fragment)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .commit();
    }

    public void reiniciarAsynkProcess() {
        buscarPedido.cancel(true);
        buscarPedido = new BuscarPedido();
    }

    public class BuscarPedido extends AsyncTask<String, String, Pedido> {

        @Override
        protected Pedido doInBackground(String... strings) {
            Pedido pedidoBuscar = new Pedido();
            try {
                PedidoService pedidoService = new PedidoService();
                pedidoBuscar = pedidoBuscar = pedidoService.obtenerPedidoPorId(Logued.pedidoLogued.getPedidoId());
            }catch (Exception e){
                System.out.println("Error en UnderThreash:" +e.getMessage() +" " +e.getClass());
            }
            return pedidoBuscar;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Pedido pedido) {
            super.onPostExecute(pedido);
            try {
                if (pedido != null){
                    Logued.pedidoLogued = pedido;
                    reiniciarAsynkProcess();
                }
            }catch (Throwable throwable){
                System.out.println("Error Activity: " +throwable.getMessage());
                throwable.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }

}
