package com.fm.modules.app.menu;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.fm.apprestaurantefuimonos.R;
import com.fm.modules.app.carrito.CarritoActivity;
import com.fm.modules.app.carrito.GlobalCarrito;
import com.fm.modules.app.carrito.PagoActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MenuBotton extends FragmentActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_botton);

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.menuHome, R.id.menuShoppingCart)
                .build();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        NavigationUI.setupWithNavController(bottomNavigationView, navController);

        showFragment(new OrdenesActuales());

        boolean openShopingCart = GlobalCarrito.toShopinCart;
        if (openShopingCart) {
            showFragment(new CarritoActivity());
            GlobalCarrito.toShopinCart = false;
        }
        boolean openSales = GlobalCarrito.toSales;
        /*if (openSales) {
            showFragment(new PagoActivity());
            GlobalCarrito.toSales = false;
        }*/

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.mmenuInicio) {
                    showFragment(new OrdenesActuales());
                }
                if (item.getItemId() == R.id.mmenuCarrito) {
                    showFragment(new CarritoActivity());
                    System.out.println("Al Carrito");
                }
                return false;
            }
        });
    }

    private void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, fragment)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .commit();
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

}